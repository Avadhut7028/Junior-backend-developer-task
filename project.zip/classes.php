
<?php
$pdo = new PDO('mysql:host=localhost;dbname=your_database', 'username', 'password');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $image = $_FILES['image'];

    if ($image && in_array($image['type'], ['image/jpeg', 'image/png'])) {
        $uploadDir = 'uploads/';
        $filename = uniqid() . '_' . basename($image['name']);
        $targetFile = $uploadDir . $filename;

        if (move_uploaded_file($image['tmp_name'], $targetFile)) {
            $stmt = $pdo->prepare('INSERT INTO classes (name, description, image_path) VALUES (?, ?, ?)');
            $stmt->execute([$name, $description, $targetFile]);
        }
    }
}

if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $pdo->prepare('DELETE FROM classes WHERE id = ?');
    $stmt->execute([$id]);
}

$classes = $pdo->query('SELECT * FROM classes')->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Classes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h1>Classes</h1>
    <form method="POST" enctype="multipart/form-data" class="mb-4">
        <div class="mb-3">
            <label class="form-label">Class Name</label>
            <input type="text" name="name" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Description</label>
            <textarea name="description" class="form-control" required></textarea>
        </div>
        <div class="mb-3">
            <label class="form-label">Image</label>
            <input type="file" name="image" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-success">Add Class</button>
    </form>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Name</th>
                <th>Description</th>
                <th>Image</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($classes as $class): ?>
            <tr>
                <td><?= htmlspecialchars($class['name']) ?></td>
                <td><?= htmlspecialchars($class['description']) ?></td>
                <td><img src="<?= htmlspecialchars($class['image_path']) ?>" alt="Class Image" style="width: 100px;"></td>
                <td>
                    <a href="edit_class.php?id=<?= $class['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                    <a href="classes.php?delete=<?= $class['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this class?');">Delete</a>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
</body>
</html>
